package com.example.SecondProjecdemo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SecondProjecDemoApplication {

	public static void main(String[] args) {
		SpringApplication.run(SecondProjecDemoApplication.class, args);
	}

}
